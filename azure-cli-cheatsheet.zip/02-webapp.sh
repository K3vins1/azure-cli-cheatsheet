az appservice plan create \
  --name myAppPlan \
  --resource-group my-rg \
  --sku FREE

az webapp create \
  --name mywebapp123 \
  --resource-group my-rg \
  --plan myAppPlan \
  --runtime "PYTHON|3.11"