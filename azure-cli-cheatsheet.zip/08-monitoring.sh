az webapp log config \
  --name mywebapp123 \
  --resource-group my-rg \
  --application-logging true

az webapp log tail \
  --name mywebapp123 \
  --resource-group my-rg