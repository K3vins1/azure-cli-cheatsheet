az storage account create \
  --name mystorageacct123 \
  --resource-group my-rg \
  --location westeurope \
  --sku Standard_LRS

az storage container create \
  --account-name mystorageacct123 \
  --name mycontainer \
  --public-access blob