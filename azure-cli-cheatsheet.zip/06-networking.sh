az network vnet create \
  --name my-vnet \
  --resource-group my-rg \
  --subnet-name my-subnet

az network nsg create \
  --resource-group my-rg \
  --name my-nsg

az network nsg rule create \
  --resource-group my-rg \
  --nsg-name my-nsg \
  --name allow-web \
  --priority 1001 \
  --access Allow \
  --protocol Tcp \
  --direction Inbound \
  --destination-port-range 80 \
  --source-address-prefix '*' \
  --source-port-range '*'