az vm create \
  --name myVM \
  --resource-group my-rg \
  --image UbuntuLTS \
  --admin-username azureuser \
  --admin-password MojeHaslo123! \
  --authentication-type password \
  --size Standard_B1s \
  --generate-ssh-keys

az vm open-port \
  --port 80 \
  --resource-group my-rg \
  --name myVM