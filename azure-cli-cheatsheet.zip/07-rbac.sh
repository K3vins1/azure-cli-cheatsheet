az role assignment create \
  --assignee user@twojadomena.com \
  --role Contributor \
  --resource-group my-rg