# Azure CLI Cheat Sheet – Junior Cloud Engineer

📘 Ten katalog zawiera podstawowe komendy do zarządzania zasobami Azure z poziomu CLI.  
📦 Idealne do portfolio, praktyki oraz egzaminu AZ-104.

## Zakres:
- App Services
- Virtual Machines
- Blob Storage
- SQL Database
- VNet + NSG
- RBAC
- Monitoring

Autor: Twoje Imię