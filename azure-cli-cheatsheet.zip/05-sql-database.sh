az sql server create \
  --name myserver123 \
  --resource-group my-rg \
  --location westeurope \
  --admin-user azureuser \
  --admin-password MojeHaslo123!

az sql db create \
  --resource-group my-rg \
  --server myserver123 \
  --name mydatabase \
  --service-objective S0

az sql server firewall-rule create \
  --resource-group my-rg \
  --server myserver123 \
  --name AllowMyIP \
  --start-ip-address YOUR.IP.HERE \
  --end-ip-address YOUR.IP.HERE